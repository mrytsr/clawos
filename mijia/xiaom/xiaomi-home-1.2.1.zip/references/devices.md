# Device Inventory Template

Add your devices here to help the agent remember their IPs and Tokens.

| Device | IP | Token | Model |
| :--- | :--- | :--- | :--- |
| Living Room Light | 192.168.1.10 | token_here | ... |
